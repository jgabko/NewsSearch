"use client"

import { useEffect, useRef } from "react"

interface FloatingOrb {
  x: number
  y: number
  baseX: number
  baseY: number
  size: number
  speed: number
  offset: number
  color: string
  glowSize: number
}

export default function AnimatedBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    let animationFrameId: number
    let orbs: FloatingOrb[] = []
    let time = 0

    const resizeCanvas = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    const initOrbs = () => {
      orbs = [
        {
          x: canvas.width * 0.15,
          y: canvas.height * 0.2,
          baseX: canvas.width * 0.15,
          baseY: canvas.height * 0.2,
          size: 500,
          speed: 0.0008,
          offset: 0,
          color: "56, 189, 248", // cyan
          glowSize: 700,
        },
        {
          x: canvas.width * 0.85,
          y: canvas.height * 0.8,
          baseX: canvas.width * 0.85,
          baseY: canvas.height * 0.8,
          size: 450,
          speed: 0.0006,
          offset: Math.PI,
          color: "59, 130, 246", // blue
          glowSize: 600,
        },
        {
          x: canvas.width * 0.5,
          y: canvas.height * 0.5,
          baseX: canvas.width * 0.5,
          baseY: canvas.height * 0.5,
          size: 600,
          speed: 0.0005,
          offset: Math.PI / 2,
          color: "14, 165, 233", // sky
          glowSize: 800,
        },
        {
          x: canvas.width * 0.3,
          y: canvas.height * 0.7,
          baseX: canvas.width * 0.3,
          baseY: canvas.height * 0.7,
          size: 350,
          speed: 0.0007,
          offset: Math.PI * 1.5,
          color: "99, 102, 241", // indigo
          glowSize: 500,
        },
      ]
    }

    const drawBackground = () => {
      if (!ctx || !canvas) return

      const breathe = Math.sin(time * 0.001) * 0.5 + 0.5

      // Base gradient - muito mais claro e azulado
      const baseGradient = ctx.createRadialGradient(
        canvas.width / 2 + Math.sin(time * 0.0005) * 100,
        canvas.height / 2 + Math.cos(time * 0.0004) * 80,
        0,
        canvas.width / 2,
        canvas.height / 2,
        canvas.width * 0.9
      )

      // Cores mais claras e azuladas
      baseGradient.addColorStop(0, `rgba(30, 58, 95, ${0.95 + breathe * 0.05})`) // azul mais claro no centro
      baseGradient.addColorStop(0.3, `rgba(15, 35, 65, 1)`) // azul escuro
      baseGradient.addColorStop(0.6, `rgba(10, 25, 50, 1)`) // azul mais escuro
      baseGradient.addColorStop(1, `rgba(5, 15, 35, 1)`) // azul muito escuro nas bordas

      ctx.fillStyle = baseGradient
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      // Orbs animados com mais brilho
      orbs.forEach((orb) => {
        orb.x = orb.baseX + Math.sin(time * orb.speed + orb.offset) * 200
        orb.y = orb.baseY + Math.cos(time * orb.speed * 1.2 + orb.offset) * 150

        // Glow externo muito mais visível
        const outerGlow = ctx.createRadialGradient(orb.x, orb.y, 0, orb.x, orb.y, orb.glowSize)
        outerGlow.addColorStop(0, `rgba(${orb.color}, ${0.35 + breathe * 0.15})`)
        outerGlow.addColorStop(0.3, `rgba(${orb.color}, ${0.2 + breathe * 0.1})`)
        outerGlow.addColorStop(0.6, `rgba(${orb.color}, ${0.08 + breathe * 0.04})`)
        outerGlow.addColorStop(1, `rgba(${orb.color}, 0)`)
        ctx.fillStyle = outerGlow
        ctx.fillRect(0, 0, canvas.width, canvas.height)

        // Core interno mais brilhante
        const innerGlow = ctx.createRadialGradient(orb.x, orb.y, 0, orb.x, orb.y, orb.size)
        innerGlow.addColorStop(0, `rgba(${orb.color}, ${0.5 + breathe * 0.2})`)
        innerGlow.addColorStop(0.4, `rgba(${orb.color}, ${0.25 + breathe * 0.1})`)
        innerGlow.addColorStop(1, `rgba(${orb.color}, 0)`)
        ctx.fillStyle = innerGlow
        ctx.fillRect(0, 0, canvas.width, canvas.height)
      })
    }

    const drawFloatingParticles = () => {
      if (!ctx || !canvas) return

      // Partículas flutuando
      const particleCount = 60
      for (let i = 0; i < particleCount; i++) {
        const x = (Math.sin(time * 0.0003 * (i + 1) + i * 2.5) * 0.5 + 0.5) * canvas.width
        const y = (Math.cos(time * 0.0004 * (i + 1) + i * 1.8) * 0.5 + 0.5) * canvas.height
        const size = 1 + Math.sin(time * 0.002 + i) * 0.5
        const opacity = 0.3 + Math.sin(time * 0.003 + i * 0.5) * 0.2

        // Glow da partícula
        const glow = ctx.createRadialGradient(x, y, 0, x, y, size * 8)
        glow.addColorStop(0, `rgba(56, 189, 248, ${opacity})`)
        glow.addColorStop(0.5, `rgba(56, 189, 248, ${opacity * 0.3})`)
        glow.addColorStop(1, "rgba(56, 189, 248, 0)")
        ctx.fillStyle = glow
        ctx.beginPath()
        ctx.arc(x, y, size * 8, 0, Math.PI * 2)
        ctx.fill()

        // Core
        ctx.fillStyle = `rgba(200, 235, 255, ${opacity + 0.2})`
        ctx.beginPath()
        ctx.arc(x, y, size, 0, Math.PI * 2)
        ctx.fill()
      }
    }

    const drawMovingLines = () => {
      if (!ctx || !canvas) return

      // Linhas de dados descendo
      const lineCount = 12
      ctx.lineWidth = 1.5

      for (let i = 0; i < lineCount; i++) {
        const baseX = (canvas.width / lineCount) * i + canvas.width / lineCount / 2
        const x = baseX + Math.sin(time * 0.001 + i * 0.8) * 80
        const yOffset = (time * 0.08 + i * 150) % (canvas.height + 400)
        
        const gradient = ctx.createLinearGradient(x, yOffset - 300, x, yOffset)
        gradient.addColorStop(0, "rgba(56, 189, 248, 0)")
        gradient.addColorStop(0.3, `rgba(56, 189, 248, ${0.05 + Math.sin(time * 0.002 + i) * 0.03})`)
        gradient.addColorStop(0.7, `rgba(56, 189, 248, ${0.15 + Math.sin(time * 0.002 + i) * 0.1})`)
        gradient.addColorStop(1, "rgba(56, 189, 248, 0)")

        ctx.strokeStyle = gradient
        ctx.beginPath()
        ctx.moveTo(x, yOffset - 300)
        ctx.lineTo(x, yOffset)
        ctx.stroke()
      }
    }

    const drawScanLine = () => {
      if (!ctx || !canvas) return

      // Linha de scan horizontal
      const scanY = (time * 0.03) % (canvas.height + 100) - 50
      const scanGradient = ctx.createLinearGradient(0, scanY - 40, 0, scanY + 40)
      scanGradient.addColorStop(0, "rgba(56, 189, 248, 0)")
      scanGradient.addColorStop(0.5, "rgba(56, 189, 248, 0.12)")
      scanGradient.addColorStop(1, "rgba(56, 189, 248, 0)")
      ctx.fillStyle = scanGradient
      ctx.fillRect(0, scanY - 40, canvas.width, 80)
    }

    const drawGrid = () => {
      if (!ctx || !canvas) return

      // Grid sutil
      const gridSize = 80
      const gridOpacity = 0.04 + Math.sin(time * 0.001) * 0.01
      
      ctx.strokeStyle = `rgba(56, 189, 248, ${gridOpacity})`
      ctx.lineWidth = 0.5

      // Linhas verticais
      for (let x = 0; x < canvas.width; x += gridSize) {
        const offset = Math.sin(time * 0.0005 + x * 0.01) * 3
        ctx.beginPath()
        ctx.moveTo(x + offset, 0)
        ctx.lineTo(x + offset, canvas.height)
        ctx.stroke()
      }

      // Linhas horizontais
      for (let y = 0; y < canvas.height; y += gridSize) {
        const offset = Math.cos(time * 0.0005 + y * 0.01) * 3
        ctx.beginPath()
        ctx.moveTo(0, y + offset)
        ctx.lineTo(canvas.width, y + offset)
        ctx.stroke()
      }
    }

    const animate = () => {
      if (!ctx || !canvas) return

      time += 16 // ~60fps

      // Desenha tudo em ordem
      drawBackground()
      drawGrid()
      drawMovingLines()
      drawFloatingParticles()
      drawScanLine()

      // Vinheta suave
      const vignette = ctx.createRadialGradient(
        canvas.width / 2,
        canvas.height / 2,
        canvas.height * 0.4,
        canvas.width / 2,
        canvas.height / 2,
        canvas.width * 0.8
      )
      vignette.addColorStop(0, "rgba(0, 0, 0, 0)")
      vignette.addColorStop(1, "rgba(0, 0, 0, 0.3)")
      ctx.fillStyle = vignette
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      animationFrameId = requestAnimationFrame(animate)
    }

    resizeCanvas()
    initOrbs()
    animate()

    window.addEventListener("resize", () => {
      resizeCanvas()
      initOrbs()
    })

    return () => {
      cancelAnimationFrame(animationFrameId)
      window.removeEventListener("resize", resizeCanvas)
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 z-0"
      style={{ pointerEvents: "none" }}
      aria-hidden="true"
    />
  )
}
