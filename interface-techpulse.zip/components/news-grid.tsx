"use client"

import { motion } from "framer-motion"
import TiltCard from "./tilt-card"

interface NewsItem {
  id: number
  category: string
  title: string
  excerpt: string
  timestamp: string
  readTime: string
  image?: string
}

const newsData: NewsItem[] = [
  {
    id: 1,
    category: "IA AVANÇADA",
    title: "Nova rede neural quântica alcança 99.7% de precisão em diagnósticos médicos",
    excerpt:
      "Pesquisadores combinam computação quântica com deep learning para revolucionar a detecção precoce de doenças.",
    timestamp: "Há 2 horas",
    readTime: "5 min",
    image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=400&h=200&fit=crop",
  },
  {
    id: 2,
    category: "CIBERSEGURANÇA",
    title: "Protocolo de criptografia pós-quântica é aprovado como novo padrão global",
    excerpt:
      "Após 8 anos de desenvolvimento, o algoritmo CRYSTALS-Kyber se torna obrigatório para comunicações governamentais.",
    timestamp: "Há 4 horas",
    readTime: "7 min",
  },
  {
    id: 3,
    category: "HARDWARE",
    title: "Chip neuromórfico de última geração processa dados 1000x mais rápido",
    excerpt:
      "Nova arquitetura inspirada no cérebro humano promete transformar data centers e dispositivos edge.",
    timestamp: "Há 6 horas",
    readTime: "4 min",
    image: "https://images.unsplash.com/photo-1518770660439-4636190af475?w=400&h=200&fit=crop",
  },
  {
    id: 4,
    category: "BLOCKCHAIN",
    title: "Rede descentralizada de energia solar conecta 10 milhões de residências",
    excerpt:
      "Sistema peer-to-peer permite que vizinhos vendam excesso de energia diretamente usando smart contracts.",
    timestamp: "Há 8 horas",
    readTime: "6 min",
  },
  {
    id: 5,
    category: "BIOTECNOLOGIA",
    title: "Interface cérebro-computador permite digitação por pensamento a 120 palavras por minuto",
    excerpt:
      "Implante neural de nova geração restaura comunicação para pacientes com paralisia total.",
    timestamp: "Há 12 horas",
    readTime: "8 min",
    image: "https://images.unsplash.com/photo-1559757175-5700dde675bc?w=400&h=200&fit=crop",
  },
  {
    id: 6,
    category: "ESPAÇO",
    title: "Starlink 3.0 promete internet de 10Gbps em qualquer lugar do planeta",
    excerpt:
      "Nova constelação de satélites com lasers ópticos elimina latência e expande cobertura global.",
    timestamp: "Há 14 horas",
    readTime: "5 min",
  },
]

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2,
    },
  },
}

const itemVariants = {
  hidden: {
    opacity: 0,
    y: 40,
    scale: 0.95,
  },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      type: "spring",
      stiffness: 100,
      damping: 15,
    },
  },
}

export default function NewsGrid() {
  return (
    <motion.div
      className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      {newsData.map((news) => (
        <motion.div key={news.id} variants={itemVariants}>
          <TiltCard>
            <article className="h-full flex flex-col">
              {/* Image Area */}
              {news.image && (
                <div className="relative h-36 overflow-hidden rounded-t-xl">
                  <img
                    src={news.image}
                    alt={news.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                </div>
              )}
              
              <div className="p-6 flex flex-col flex-grow">
                {/* Category Badge */}
                <div className="flex items-center gap-3 mb-4">
                <span className="px-3 py-1 text-xs font-bold tracking-wider bg-cyan-500/20 text-cyan-400 rounded-full border border-cyan-500/30">
                  {news.category}
                </span>
                <span className="text-xs text-cyan-300/60 font-mono">{news.readTime}</span>
              </div>

              {/* Title */}
              <h3 className="text-lg font-bold text-white leading-tight mb-3 line-clamp-2 text-balance">
                {news.title}
              </h3>

              {/* Excerpt */}
              <p className="text-sm text-gray-400 leading-relaxed mb-5 line-clamp-3 flex-grow">
                {news.excerpt}
              </p>

              {/* Footer */}
              <div className="flex items-center justify-between mt-auto pt-4 border-t border-white/5">
                <span className="text-xs font-mono text-cyan-400/70">{news.timestamp}</span>
                <motion.button
                  className="group relative px-4 py-2 text-xs font-bold tracking-wider text-cyan-400 rounded-lg border border-cyan-500/50 overflow-hidden transition-colors duration-300 hover:text-cyan-900"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <span className="relative z-10">LER NOTÍCIA</span>
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-blue-500"
                    initial={{ x: "-100%" }}
                    whileHover={{ x: 0 }}
                    transition={{ duration: 0.3, ease: "easeInOut" }}
                  />
                </motion.button>
              </div>
            </div>
            </article>
          </TiltCard>
        </motion.div>
      ))}
    </motion.div>
  )
}
