"use client"

import { motion } from "framer-motion"
import AnimatedBackground from "@/components/animated-background"
import NewsGrid from "@/components/news-grid"

export default function Page() {
  return (
    <main className="relative min-h-screen overflow-hidden">
      {/* Animated Background */}
      <AnimatedBackground />

      {/* Scanlines overlay */}
      <div
        className="fixed inset-0 pointer-events-none z-10 opacity-[0.02]"
        style={{
          backgroundImage: `repeating-linear-gradient(
            0deg,
            transparent,
            transparent 2px,
            rgba(0, 0, 0, 0.3) 2px,
            rgba(0, 0, 0, 0.3) 4px
          )`,
        }}
        aria-hidden="true"
      />

      {/* Vignette overlay */}
      <div
        className="fixed inset-0 pointer-events-none z-10"
        style={{
          background: `radial-gradient(ellipse at center, transparent 0%, transparent 40%, rgba(0, 0, 0, 0.4) 100%)`,
        }}
        aria-hidden="true"
      />

      {/* Content */}
      <div className="relative z-20 flex flex-col items-center justify-center min-h-screen px-4 py-12">
        {/* Minimal Header */}
        <motion.header
          className="text-center mb-12"
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <motion.div
            className="inline-flex items-center gap-2 mb-4"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
          >
            <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
            <span className="text-xs font-mono text-cyan-400/80 tracking-[0.3em] uppercase">
              Sistema Online
            </span>
          </motion.div>

          <h1 className="text-4xl md:text-6xl font-black tracking-tighter text-white mb-3">
            <span className="bg-gradient-to-r from-cyan-400 via-blue-400 to-cyan-300 bg-clip-text text-transparent">
              TECH PULSE
            </span>
          </h1>

          <motion.p
            className="text-sm md:text-base font-mono text-cyan-400/50 tracking-wide"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.6 }}
          >
            TRANSMISSÃO_DE_DADOS_EM_TEMPO_REAL
          </motion.p>

          {/* Decorative line */}
          <motion.div
            className="mt-6 mx-auto h-px w-48 bg-gradient-to-r from-transparent via-cyan-500/50 to-transparent"
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ delay: 0.6, duration: 0.8 }}
          />
        </motion.header>

        {/* News Grid Container */}
        <div className="w-full max-w-7xl mx-auto">
          <NewsGrid />
        </div>

        {/* Footer indicator */}
        <motion.footer
          className="mt-16 text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5, duration: 0.8 }}
        >
          <div className="flex items-center justify-center gap-4 text-xs font-mono text-cyan-500/40">
            <span className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
              CONEXÃO SEGURA
            </span>
            <span className="text-cyan-500/20">|</span>
            <span>LATÊNCIA: 12ms</span>
            <span className="text-cyan-500/20">|</span>
            <span>NODES ATIVOS: 847</span>
          </div>
        </motion.footer>
      </div>
    </main>
  )
}
